create procedure hi()
  select 'hello';

