create procedure sp_wo_statistic(IN p_wo_group char(20))
  BEGIN
SELECT * FROM work_orders WHERE wo_group = p_wo_group;
    END;

